import numpy as np
from random import shuffle


# tính toán mất mát và gradient
def svm_loss_naive(W, X, y, reg):
    d, C = W.shape
    _, N = X.shape
    loss = 0
    dW = np.zeros_like(W)
    for n in range(N):
        xn = X[:, n]
        score = W.T.dot(xn)
        for j in range(C):
            if j == y[n]:
                continue
            margin = 1 - score[y[n]] + score[j]
            if margin > 0:
                loss += margin
                dW[:, j] += xn
                dW[:, y[n]] -= xn

    loss /= N
    loss += 0.5 * reg * np.sum(W * W)  # chính quy

    dW /= N
    dW += reg * W  # sự tắt liên tục gradient
    return loss, dW


# ngẫu nhiên, dữ liệu nhỏ
N, C, d = 10, 3, 5
reg = .1
W = np.random.randn(d, C)
X = np.random.randn(d, N)
y = np.random.randint(C, size=N)

# kiểm tra sanity
print('loss without regularization:', svm_loss_naive(W, X, y, 0)[0])
print('loss with regularization:')
svm_loss_naive(W, X, y, .1)[0]
f = lambda W: svm_loss_naive(W, X, y, .1)[0]


# kiểm tra nếu tính toán grad là chính xác
def numerical_grad_general(W, f):
    eps = 1e-6
    g = np.zeros_like(W)
    # biến dẹt -> 1d. Sau đó chúng ta cần
    # chỉ một cho vòng lặp
    W_flattened = W.flatten()
    g_flattened = np.zeros_like(W_flattened)

    for i in range(W.size):
        W_p = W_flattened.copy()
        W_n = W_flattened.copy()
        W_p[i] += eps
        W_n[i] -= eps

        # back to shape of W
        W_p = W_p.reshape(W.shape)
        W_n = W_n.reshape(W.shape)
        g_flattened[i] = (f(W_p) - f(W_n)) / (2 * eps)

    # chuyển đổi về hình dạng ban đầu
    return g_flattened.reshape(W.shape)


# so sánh hai cách tính toán gradient
g1 = svm_loss_naive(W, X, y, .1)[1]
g2 = numerical_grad_general(W, f)
print('gradient difference: %f' % np.linalg.norm(g1 - g2))